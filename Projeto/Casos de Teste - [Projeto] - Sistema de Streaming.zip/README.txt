Arquivo zip gerado em: 18/09/2021 23:34:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Projeto] - Sistema de Streaming